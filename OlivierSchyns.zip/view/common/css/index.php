<?php
header('Location: ../../../');
exit();
?>