<?php
header('Location: ../../');
exit();
?>