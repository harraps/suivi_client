<?php
header('Location: ../');
exit();
?>